import React from 'react'

const ComFunctImg3 = () => {
  return (
    <>
        <h2>이미지 - 함수컴포넌트</h2>
        <p><img src="./images/star-ye.png" alt=""/></p>
    </>
  )
}

export default ComFunctImg3;
