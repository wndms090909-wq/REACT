import React from 'react'

const Jsx1Variable = () => {
  let uName = "홍길동"
  return (
    <div>
      <h2>jsx 문법 - 변수 사용하기</h2>
      <p>안녕~~~ {uName} 반가워!!!</p>
      
    </div>
  )
}

export default Jsx1Variable